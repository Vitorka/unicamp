#include "physics.h"

#include <math.h>
#include <stdlib.h>
#include <string.h>

void physics_update(qtree *tree, list *entities) {
}
