#include <stdlib.h>

#include "entities.h"

ball* entity_createBall(int id, double x, double y, double vx, double vy, double radius) {
    return NULL;
}

void entity_destroyBall(ball *b) {
}
