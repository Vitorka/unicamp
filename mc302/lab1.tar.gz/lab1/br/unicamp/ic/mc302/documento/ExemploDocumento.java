package br.unicamp.ic.mc302.documento;

class ExemploDocumento{ 
    static public void main(String args[ ]){ 
        Documento d1; // declara��o de uma refer�ncia para um 
                      // objeto do tipo Documento  
        d1 = new Documento( ); //aloca��o din�mica de mem�ria para a 
                                       //cria��o do objeto
        d1.criarDocumento("Camila",181101);
        d1.imprimir( ); // envio de mensagem para o objeto
        d1.editar(); //envio de mensagem para o objeto
        
        Documento d2; //declaracao de uma referencia para um objeto do tipo Documento
        
        d2 = new Documento(); //alocacao dinamica de memoria para a criacao do objeto
        
        d2.criarDocumento("Vitor", 178474);
        d2.imprimir();
    }
}
