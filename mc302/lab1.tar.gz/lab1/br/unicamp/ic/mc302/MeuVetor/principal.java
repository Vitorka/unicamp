package br.unicamp.ic.mc302.MeuVetor;

public class principal {

	public static void main(String[] args) {
		int[] vetor1 = {1, 2, 3, 4};
		int[] vetor2 = {5, 6, 7, 8};
		int[] vetor_final = new int[8];
		
		MeuVetor vetor_final2 = new MeuVetor();
		
		vetor_final2.inicializa_vetor(vetor_final);
		
		vetor_final2.intercala(vetor1, vetor2);
		
		vetor_final2.imprime();
	}
}
