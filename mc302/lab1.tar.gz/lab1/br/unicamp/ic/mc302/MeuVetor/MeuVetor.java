package br.unicamp.ic.mc302.MeuVetor;

public class MeuVetor {
int[] vetor;
	
	public void inicializa_vetor(int[] vetor1)
	{
		vetor = vetor1;
	}
	
	public void intercala(int[] vetor1, int[] vetor2)
	{
		for(int i = 0, j = 0; i < vetor1.length; i++)
		{
			vetor[j] = vetor1[i];
			vetor[j + 1] = vetor2[i];
			j += 2;
		}
	}
	
	public void imprime()
	{
		for(int i = 0; i < vetor.length; i++)
		{
			System.out.println(vetor[i]);
		}
	}
}
