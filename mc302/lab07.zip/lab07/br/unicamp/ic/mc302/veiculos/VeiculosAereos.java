package br.unicamp.ic.mc302.veiculos;

public abstract class VeiculosAereos extends Veiculo 
{
	private int lotacao;
	private int carga;
	
	public VeiculosAereos(int ano, String mar, String mod, int argCarga, int argLotacao)
	{
		super(ano,  mar, mod);
		lotacao = argLotacao;
		carga = argCarga;
	}
	
	public void mostra()
	{
		super.mostra();
		System.out.println("Lota��o = " + lotacao);
		System.out.println("Carga = " + carga);
	}
}
