package br.unicamp.ic.mc302.contaCor;

public class ExemploDoisConstrutores {

	public static void main(String[] args) {
		
		ContaCor contacor1, contacor2;
		int numeroChico = 30;
		int senhaChico = 99;
		
		contacor1 = new ContaCor("Chico", 0, numeroChico, senhaChico);
		contacor2 = new ContaCor("Chico", numeroChico, senhaChico);
		
		//Imprime as informacoes de Contacor1
		System.out.println("Contacor1:");
		System.out.println(contacor1.getEstado());
		System.out.println(contacor1.getNome());
		System.out.println(contacor1.getNumConta());
		System.out.println(contacor1.getSaldo(senhaChico));
		System.out.println(contacor1.getSenha());
		
		//Imprime as informacoes de Contacor2
		System.out.println("Contacor2:");
		System.out.println(contacor2.getEstado());
		System.out.println(contacor2.getNome());
		System.out.println(contacor2.getNumConta());
		System.out.println(contacor2.getSaldo(senhaChico));
		System.out.println(contacor2.getSenha());
	}

}
