package br.unicamp.ic.mc302.contaCor;

public class ContaEspPoup extends ContaEsp{
	
	public ContaEspPoup(String nome, double val, int num, int pwd)
	{
		super(nome, val, num, pwd);
	}
	
	public boolean debitaValor(double val, int pwd)
	{
		if (estado != ATIVA)
			return (false); // conta deve estar ativa
		if (val <= 0)
			return (false); // val>0;
		if (pwd != senha)
			return (false); // senha deve ser valida
		if (val > saldoAtual)
			return (false); // val<= saldoAtual
		saldoAtual -= val; // debita valor
		if (saldoAtual == 0)
			estado = INATIVA; // se saldo=0, torna conta inativa
		return (true);
	}
}
