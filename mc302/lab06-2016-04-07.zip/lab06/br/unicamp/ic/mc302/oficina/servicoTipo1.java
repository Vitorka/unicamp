package br.unicamp.ic.mc302.oficina;

public class servicoTipo1 extends Servicos
{
	public servicoTipo1()
	{
		preco = 15;
	}
}
