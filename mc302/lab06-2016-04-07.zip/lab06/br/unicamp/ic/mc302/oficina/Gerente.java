package br.unicamp.ic.mc302.oficina;

import java.util.ArrayList;

public class Gerente extends Funcionario 
{
	public Gerente(int numero, boolean gerencia)
	{
		super(numero, gerencia);
		salario = 700;
	}

	//Calcula a comissao que o gerente deve receber
	public void calculaComissao(int sTipo1, int sTipo2, int sTipo3, ArrayList <Servicos> servicos)
	{
		comissao += servicos.get(0).getPreco() * 0.15 * sTipo1;
		comissao += servicos.get(1).getPreco() * 0.15 * sTipo2;
		comissao += servicos.get(2).getPreco() * 0.15 * sTipo3;
	}
}
