package br.unicamp.ic.mc302.oficina;

import java.util.ArrayList;

public class Funcionario 
{
	protected int numero;
	protected double salario;
	protected double comissao = 0;
	protected boolean gerencia;
	
	public Funcionario(int numero, boolean gerencia)
	{	
		if(!gerencia)
		{
			salario = 400;
		}
		this.numero = numero;
		this.gerencia = gerencia;
	}
	
	//Calcula a comissao que o gerente deve receber
	public void calculaComissao(int sTipo1, int sTipo2, int sTipo3, ArrayList <Servicos> servicos)
	{
		comissao += servicos.get(0).getPreco() * 0.1 * sTipo1;
		comissao += servicos.get(1).getPreco() * 0.1 * sTipo2;
		comissao += servicos.get(2).getPreco() * 0.1 * sTipo3;
	}
	
	//Retorna a comissao que o funcionario recebera pelos servicos realizados
	public double getComissao()
	{
		return comissao;
	}
	
	//Retorna o salario que o funcionario recebe
	public double getSalario()
	{
		return salario;
	}
	
	//Retorna se o funcionario eh gerente
	public boolean getGerente()
	{
		return gerencia;
	}
	
	//Retorna o numero do funcionario
	public int getNumero()
	{
		return numero;
	}
}
