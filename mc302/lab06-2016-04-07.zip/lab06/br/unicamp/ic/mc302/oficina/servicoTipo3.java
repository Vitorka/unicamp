package br.unicamp.ic.mc302.oficina;

public class servicoTipo3 extends Servicos
{
	public servicoTipo3()
	{
		preco = 40;
	}
}
