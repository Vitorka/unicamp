package br.unicamp.ic.mc302.oficina;

import java.util.ArrayList;

public class Oficina 
{
	protected ArrayList <Funcionario> funcionarios;
	protected ArrayList <Servicos> servicos;
	protected servicoTipo1 s1;
	protected servicoTipo2 s2;
	protected servicoTipo3 s3;
	
	public Oficina()
	{
		servicos = new ArrayList <Servicos>();
		s1 = new servicoTipo1();
		servicos.add(s1);
		s2 = new servicoTipo2();
		servicos.add(s2);
		s3 = new servicoTipo3();
		servicos.add(s3);
		
		funcionarios = new ArrayList <Funcionario>();
	}
	
	//Adiciona os dados dos funcionarios
	public void dadosFuncionario(int numero, int sTipo1, int sTipo2, int sTipo3, boolean verificaGerente)
	{
		if(verificaGerente)
		{
			Gerente gerente = new Gerente(numero, verificaGerente);
			gerente.calculaComissao(sTipo1, sTipo2, sTipo3, servicos);
			funcionarios.add(gerente);
		}
		else
		{
			Funcionario funcionario = new Funcionario(numero, verificaGerente);
			funcionario.calculaComissao(sTipo1, sTipo2, sTipo3, servicos);
			funcionarios.add(funcionario);
		}
	}
	
	//Imprime os dados dos funcionarios
	public void imprimeDados(int numero)
	{
		System.out.println("Numero do funcionario: " + numero);
		for(int i = 0; i < funcionarios.size(); i++)
		{
			if(funcionarios.get(i).getNumero() == numero)
			{
				System.out.print("Gerencia: ");
				if(funcionarios.get(i).getGerente())
				{
					System.out.println("Sim");
				}
				else
				{
					System.out.println("Não");
				}
				
				System.out.println("Salario: " + funcionarios.get(i).getSalario());
				System.out.println("Comissao: " + funcionarios.get(i).getComissao());
			}
		}
		System.out.println();
	}
}
