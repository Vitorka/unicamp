package br.unicamp.ic.mc302.oficina;

public class servicoTipo2 extends Servicos
{
	public servicoTipo2()
	{
		preco = 50;
	}
}
