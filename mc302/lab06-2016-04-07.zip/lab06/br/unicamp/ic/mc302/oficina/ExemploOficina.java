package br.unicamp.ic.mc302.oficina;

import java.util.Scanner;

public class ExemploOficina
{
	public static void main(String[]args)
	{
		Scanner scan = new Scanner(System.in);
		Oficina oficina = new Oficina();
		int numero, sTipo1, sTipo2, sTipo3;
		boolean verificaGerente;
		
		System.out.print("Entre com o numero do funcionario: ");
		numero = scan.nextInt();
		System.out.println();
		
		System.out.print("Entre com a quantidade de cada tipo de servico realizado: ");
		sTipo1 = scan.nextInt();
		sTipo2 = scan.nextInt();
		sTipo3 = scan.nextInt();
		System.out.println();
		
		System.out.print("O funcionario eh gerente: ");
		verificaGerente = scan.nextBoolean();
		System.out.println();
		
		oficina.dadosFuncionario(numero, sTipo1, sTipo2, sTipo3, verificaGerente);
		oficina.imprimeDados(numero);
		
		scan.close();
	}
}
