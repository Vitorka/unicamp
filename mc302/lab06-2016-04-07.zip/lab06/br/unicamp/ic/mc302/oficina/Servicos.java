package br.unicamp.ic.mc302.oficina;

public class Servicos 
{
	protected double preco;
	
	public double getPreco()
	{
		return preco;
	}
}
