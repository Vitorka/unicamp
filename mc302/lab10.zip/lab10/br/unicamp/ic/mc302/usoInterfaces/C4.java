package br.unicamp.ic.mc302.usoInterfaces;

public class C4 implements I4, I5 {

	public void m4() {
		System.out.println("Metodo m4() da classe C4 executado!");
	}

	public void m5() {
		System.out.println("Metodo m5() da classe C4 executado!");
	}

}
