package br.unicamp.ic.mc302.exemploSimples;

public interface I1 {

	public void m1();

}