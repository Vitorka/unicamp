package br.unicamp.ic.mc302.exemploSimples;

public class C2 implements I1 {
	
	public void m1()
	{
		System.out.println("Metodo m1() executado!");
	}

}
