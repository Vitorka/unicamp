package br.unicamp.ic.mc302.documento2;

public class ExCartaEncomenda {

	public static void main(String[] args) {
		
		CartaRegistrada cr1;
		Encomenda e1;
		
		cr1 = new CartaRegistrada("Campinas", "27/06/1996");
		e1 = new Encomenda("Campinas", "27/06/1996", "Cartao postal");
		
		cr1.imprimir();
		e1.imprimir();
	}

}
