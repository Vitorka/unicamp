package br.unicamp.ic.mc302.pessoa;

public class Pessoa {
	protected String nome, rg, cpf;
	protected String nome_pai, nome_mae;
	
	public Pessoa(String nome, String rg, String cpf, String nome_pai, String nome_mae)
	{
		this.nome = nome;
		this.rg = rg;
		this.cpf = cpf;
		this.nome_pai = nome_pai;
		this.nome_mae = nome_mae;
	}

}
