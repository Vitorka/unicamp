package br.unicamp.ic.mc302.pessoa;

public class Graduando extends EstudanteUniversitario {
	
	public Graduando(String nome, String rg, String cpf, String nome_pai, String nome_mae, String RA, String curso, double cred_concl)
	{
		super(nome, rg, cpf, nome_pai, nome_mae, RA, curso, cred_concl);
	}
	
	public double calcula_CR(double nota1, double peso1, double nota2, double peso2)
	{
		return (((nota1 * peso1) + (nota2 * peso2)) / (peso1 + peso2));
	}
	
	public double calcula_CP(double credito_total, double credito_atual)
	{
		return credito_atual / credito_total;
	}
	
	public void imprimir()
	{
		System.out.println(nome);
		System.out.println(rg);
		System.out.println(cpf);
		System.out.println(nome_pai);
		System.out.println(nome_mae);
		System.out.println(RA);
		System.out.println(curso);
		System.out.println(cred_concl);
	}

}
