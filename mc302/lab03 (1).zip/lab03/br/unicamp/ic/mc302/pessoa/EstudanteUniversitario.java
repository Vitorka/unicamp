package br.unicamp.ic.mc302.pessoa;

public class EstudanteUniversitario extends Pessoa {
	
	protected String RA, curso;
	protected double cred_concl;
	
	public EstudanteUniversitario(String nome, String rg, String cpf, String nome_pai, String nome_mae, String RA, String curso, double cred_concl)
	{
		super(nome, rg, cpf, nome_pai, nome_mae);
		this.RA = RA;
		this.curso = curso;
		this.cred_concl = cred_concl;
	}

}
