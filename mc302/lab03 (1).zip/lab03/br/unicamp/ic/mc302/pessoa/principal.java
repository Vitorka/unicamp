package br.unicamp.ic.mc302.pessoa;

public class principal {

	public static void main(String[] args) {
		Graduando aluno;
		
		aluno = new Graduando("Vitor", "436985217", "14523698745", "Edson", "Cecilia", "178474", "Engenharia de computação", 50);
		
		aluno.imprimir();
	}

}
