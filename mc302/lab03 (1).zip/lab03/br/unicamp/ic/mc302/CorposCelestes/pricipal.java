package br.unicamp.ic.mc302.CorposCelestes;

public class pricipal {

	public static void main(String[] args) {
		
		boolean plang, plant, estr, l;		
		boolean corpo_orbitando;
		
		//Se necessario cria um objeto para planeta gasoso
		if(plang)
		{
			PlanetasGasosos planetasg;
			planetasg = new PlanetasGasosos("Terra",8378934, 988984, 36, "Hidrogenio");
		}
		//Se necessario cria um objeto para planeta terrestre
		if(plant)
		{
			PlanetasTerrestres planetast;
			planetast = new PlanetasTerrestres("Terra",8378934, 988984, 36, "Oxigenio");
		}
		//Se necessario cria um objeto para Estrela
		if(estr)
		{
			Estrela estrela;
			estrela = new Estrela("Sol",8378934, 988984, 36, 66432);
		}
		//Se necessario cria um objeto para Lua
		if(l)
		{
			Lua lua;
			lua = new Lua("Terra",8378934, 988984, 36, "Captura");
		}
		
		if(corpo_orbitando)
		{
			//Adiciona um novo corpo na lista de corpos presentes na orbita, atraves da funcao adcionarCorpos presente na classe CorposCelestes
		}

	}

}
