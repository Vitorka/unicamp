package br.unicamp.ic.mc302.CorposCelestes;

import java.util.ArrayList;

public class CorposCelestes {
	protected String nome;
	protected double diametro, massa, temperatura;
	ArrayList<CorposCelestes> corpos_orbita;
	
	public CorposCelestes(String nome, double diametro, double massa, double temperatura)
	{
		this.nome = nome;
		this.diametro = diametro;
		this.massa = massa;
		this.temperatura = temperatura;
		corpos_orbita = new ArrayList<CorposCelestes>(); 
	}
	
	public void rotacao(){		
	}
	
	public void translacao(){		
	}
	
        //Realiza uma agregacao das classes do tipo CorposCelestes
	public void adicionarCorpos(CorposCelestes corpo)
	{
		corpos_orbita.add(corpo);
	}
}
