package br.unicamp.ic.mc302.CorposCelestes;

public class PlanetasGasosos extends CorposCelestes {
	
	protected String composicao_gas;
	
	public PlanetasGasosos(String nome, double diametro, double massa, double temperatura, String composicao)
	{
		super(nome, diametro, massa, temperatura);
		composicao_gas = composicao;
	}
}
