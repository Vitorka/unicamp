package br.unicamp.ic.mc302.CorposCelestes;

public class Lua extends CorposCelestes {
	
	protected String processo_formacao;
	
	public Lua(String nome, double diametro, double massa, double temperatura, String processo_formacao)
	{
		super(nome, diametro, massa, temperatura);
		this.processo_formacao = processo_formacao;
	}
}
