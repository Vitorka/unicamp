package br.unicamp.ic.mc302.CorposCelestes;

public class Estrela extends CorposCelestes {
	
	protected double tempo_vida;
	
	public Estrela(String nome, double diametro, double massa, double temperatura, double tempo_vida)
	{
		super(nome, diametro, massa, temperatura);
		this.tempo_vida = tempo_vida;
	}
}
