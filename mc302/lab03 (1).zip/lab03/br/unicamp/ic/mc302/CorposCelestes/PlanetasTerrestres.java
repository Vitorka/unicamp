package br.unicamp.ic.mc302.CorposCelestes;

public class PlanetasTerrestres extends CorposCelestes {
	
	protected String composicao_solo;
	
	public PlanetasTerrestres(String nome, double diametro, double massa, double temperatura, String composicao_solo)
	{
		super(nome, diametro, massa, temperatura);
		this.composicao_solo = composicao_solo;
	}
}
