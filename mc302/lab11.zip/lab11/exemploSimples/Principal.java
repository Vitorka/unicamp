public class Principal {

    public static void main(String args[]) {
    
        C1 obj = new C1();
        obj.m1();    
    }
}
