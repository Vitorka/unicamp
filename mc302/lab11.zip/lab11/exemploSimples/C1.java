
public class C1 {

    public void m1()
    {
        System.out.println("Metodo m1() da classe C1 executado!");
    }
}
