package p1;

public class C2 {

    public void m2()
    {
        System.out.println("Metodo m2() da classe C2 executado!");
    }
}
