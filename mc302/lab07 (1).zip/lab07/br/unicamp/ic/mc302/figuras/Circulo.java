package br.unicamp.ic.mc302.figuras;

class Circulo extends Figura {

	private int raio;
	private int centroX;
	private int centroY;

	void esconder() {
		System.out.println("esconder() de Circulo.");
	}

	/*void mostrar(int x, int y) {
		System.out.println("mostrar() de Circulo. (" + x + ", " + y + ")");
	}*/
}
