package br.unicamp.ic.mc302.veiculos;

public abstract class VeiculosTerrestres extends Veiculo 
{
	String placa;
	
	public VeiculosTerrestres(int ano, String mar, String mod, String pl)
	{
		super(ano, mar, mod);
		placa = pl;
	}
	
	public void mostra()
	{
		super.mostra();
		System.out.println("Placa = " + placa);
	}
	
	public String toString()
	{
		return (super.toString() + "\nPlaca = " + placa);
	}
}
