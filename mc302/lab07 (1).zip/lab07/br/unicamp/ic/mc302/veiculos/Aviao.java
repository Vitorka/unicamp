package br.unicamp.ic.mc302.veiculos;

class Aviao extends VeiculosAereos {

	private int numTurbinas;

	Aviao(int argCarga, int argNumTurbinas, int argLotacao, int ano, String mar, String mod) {
		super(ano, mar, mod, argCarga, argLotacao);
		numTurbinas = argNumTurbinas;
	}

	public void mostra() {
		System.out.println("\nTipo-->Aviao");
		System.out.println("Num. de Turbinas = " + numTurbinas);
		super.mostra();
	}
	
	public boolean ligar()
	{
		System.out.println("O aviao foi ligado corretamente");
		return true;
	}
}
