package br.unicamp.ic.mc302.onibus;

public class ExemploOnibus 
{

	public static void main(String[] args) 
	{
		Onibus reservas;

		reservas = new OnibusLeito();
		
		System.out.println("-----------------------");
		if(reservas instanceof OnibusLeito)
		{
			System.out.println("Onibus Leito");
		}
		else
		{
			System.out.println("Onibus Convencional");
		}
		System.out.println();
				
		reservas.verificaPoltronas(1, 'A', reservas.getPreco(1));
		reservas.verificaPoltronas(3, 'D', reservas.getPreco(3));
		reservas.verificaPoltronas(4, 'C', reservas.getPreco(4));
		reservas.verificaPoltronas(4, 'C', reservas.getPreco(4));
		reservas.verificaPoltronas(5, 'D', reservas.getPreco(5));
		reservas.verificaPoltronas(2, 'A', reservas.getPreco(2));
		reservas.verificaPoltronas(1, 'C', reservas.getPreco(1));
		reservas.verificaPoltronas(4, 'B', reservas.getPreco(4));
		
		reservas = new OnibusConvencional();
		
		System.out.println("-----------------------");
		if(reservas instanceof OnibusLeito)
		{
			System.out.println("Onibus Leito");
		}
		else
		{
			System.out.println("Onibus Convencional");
		}
		System.out.println();
		
		reservas.verificaPoltronas(1, 'A', reservas.getPreco(1));
		reservas.verificaPoltronas(3, 'D', reservas.getPreco(3));
		reservas.verificaPoltronas(4, 'C', reservas.getPreco(4));
		reservas.verificaPoltronas(4, 'C', reservas.getPreco(4));
		reservas.verificaPoltronas(5, 'D', reservas.getPreco(5));
		reservas.verificaPoltronas(2, 'A', reservas.getPreco(2));
		reservas.verificaPoltronas(1, 'C', reservas.getPreco(1));
		reservas.verificaPoltronas(4, 'B', reservas.getPreco(4));
	}
}
