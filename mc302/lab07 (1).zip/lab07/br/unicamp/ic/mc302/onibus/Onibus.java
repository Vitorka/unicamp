package br.unicamp.ic.mc302.onibus;

public abstract class Onibus 
{
	private char[][] poltronas;
	private int vagasDisponiveis;
	private double totalVendas;
	
	public Onibus(int assentos, int fileiras, int vagasDisponiveis)
	{
		poltronas = new char[assentos + 1][fileiras + 1];
		
		for(int i = 0; i < poltronas.length; i++)
		{
			for(int j = 0; j < poltronas[i].length; j++)
			{
				poltronas[i][j] = '0';
			}
		}
		
		poltronas[0][0] = 'A';
		poltronas[1][0] = 'B';
		poltronas[2][0] = 'C';
		poltronas[3][0] = 'D';
		poltronas[4][0] = ' ';
		for(int i = 1; i < poltronas[4].length; i++)
		{
			poltronas[4][i] = Character.forDigit(i, 10);
		}
		
		this.vagasDisponiveis = vagasDisponiveis;
		totalVendas = 0;
	}
	
	public void verificaPoltronas(int fileira, char assento, double precoPoltrona)
	{
		int numAssento = retornaAssento(assento);
		
		if((fileira >= 0) && (vagasDisponiveis > 0) && 
		   (poltronas[numAssento][fileira] == '0'))
		{
			poltronas[numAssento][fileira] = '*';
			System.out.println("Reserva efetuada!");
			vagasDisponiveis--;
			calculaValorVendas(precoPoltrona);
		}
		else
		{
			System.out.println("Poltrona ocupada! Tente outra.");
		}
		
		imprimeAssentos(poltronas);
	}
	
	private void calculaValorVendas(double precoPoltrona)
	{
		totalVendas += precoPoltrona;
	}
	
	public int assentosDisponiveis()
	{
		return vagasDisponiveis;
	}
	
	private int retornaAssento(char assento)
	{
		if(assento == 'A')
		{
			return 0;
		}
		else if(assento == 'B')
		{
			return 1;
		}
		else if(assento == 'C')
		{
			return 2;
		}
		else
		{
			return 3;
		}
	}
	
	public void imprimeAssentos(char assentos[][])

	{
		for(int i = 0; i < assentos.length; i++)
		{
			for(int j  = 0; j < assentos[i].length; j++)
			{
				if((i == 4) && (j == 10))
				{
					System.out.print("10");
				}
				else
				{
					System.out.print(assentos[i][j] + " ");
				}
			}
			System.out.println();
		}
		System.out.print("Preco total: ");
		System.out.println(totalVendas);
		System.out.println();
	}
	
	public abstract double getPreco(int fileira);
}
