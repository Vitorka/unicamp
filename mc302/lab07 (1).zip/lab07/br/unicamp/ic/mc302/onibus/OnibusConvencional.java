package br.unicamp.ic.mc302.onibus;

public class OnibusConvencional extends Onibus 
{
	public OnibusConvencional()
	{
		super(4, 10, 40);
	}
	
	public double getPreco(int fileira)
	{
		if((fileira == 1) || (fileira == 2))
		{
			return 35;
		}
		else
		{
			return 20;
		}
	}
}
