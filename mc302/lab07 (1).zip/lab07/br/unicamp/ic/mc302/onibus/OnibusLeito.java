package br.unicamp.ic.mc302.onibus;

public class OnibusLeito extends Onibus
{
	private double precoPassagem;
	
	public OnibusLeito()
	{
		super(4, 5, 20);
		precoPassagem = 40;
	}
	
	public double getPreco(int fileira)
	{
		return precoPassagem;
	}

}
