package br.unicamp.ic.mc302.contador;

// Arquivo ContadorVogais.java
public class ContadorVogais {

    public static void main(String args[]) {
	    char fraseExaminada[] = {'T','e','x','t','o',' ','E','x','e','m','p','l','o',' ','P','a','r','a',' ','A',' ','C','o','n','t','a','g','e','m',' ','D','o',' ','N','u','m','e','r','o',' ','D','e',' ','V','o','g','a','i','s','.'};
		Contador[] contVogais = new Contador[5]; // um para cada vogal
	    
	    for(int i = 0; i< fraseExaminada.length; i++){
	    	// analisar cada índice do vetor de caracteres fraseExaminada[i] e, se for o caso, incrementar o contador da respectiva vogal
	    }
    }
} // Fim da classe ContadorVogais
