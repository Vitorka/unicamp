package br.unicamp.ic.mc302.pessoa;

public class ExemploPed 
{
	public static void main(String[] args) 
	{
		PED ped;
		ped = new PED("Vitor", "893274897234", "893748937472", "Edson", "Cecilia", "178474", "Engenharia de computação", 50);
		
		ped.atribuiDisciplinas("F513 - Física Quantica 7");
		ped.atribuiDisciplinas("MC294 - Computação Gráfica");
		
		ped.mediaNotas(5.7, 8.3, 3, 4);
		
		System.out.println("Tempo de aposentadoria: " + ped.tempoAposentadoria(60, 15));
		
		ped.imprimeDiscip();
	}

}
