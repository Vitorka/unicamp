package br.unicamp.ic.mc302.pessoa;

public class PosGraduando extends EstudanteUniversitario
{
	public PosGraduando(String nome, String rg, String cpf, 
		                String nomePai, String nomeMae, String ra, String curso, int cc)
	{
		super(nome, rg, cpf, nomePai, nomeMae, ra, curso, cc);
	}
	
	//Calcula a media de notas de um aluno de Pos-Graduacao
	public double mediaNotas(double nota1, double nota2, double peso1, double peso2)
	{
		return (((nota1 * peso1) + (nota2 * peso2)) / (peso1 + peso2));
	}
}
