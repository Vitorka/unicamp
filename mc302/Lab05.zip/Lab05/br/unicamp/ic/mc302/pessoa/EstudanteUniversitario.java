package br.unicamp.ic.mc302.pessoa;

public class EstudanteUniversitario extends Pessoa 
{
	String ra;
	String curso;
	int cc;
	
	public EstudanteUniversitario(String nome, String rg, String cpf, 
		                          String nomePai, String nomeMae, String ra, String curso, int cc)
	{
		super(nome, rg, cpf, nomePai, nomeMae);
		this.ra = ra;
		this.curso = curso;
		this.cc = cc;
	}
	

}
