package br.unicamp.ic.mc302.pessoa;

public class Pessoa 
{
	String nome;
	String rg;
	String cpf;
	String nomePai;
	String nomeMae;
	
	public Pessoa(String nome, String rg, String cpf, String nomePai, String nomeMae)
	{
		this.nome = nome;
		this.rg = rg;
		this.cpf = cpf;
		this.nomePai = nomePai;
		this.nomeMae = nomeMae;
	}
}
