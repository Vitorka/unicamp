package br.unicamp.ic.mc302.pessoa;

import java.util.ArrayList;

public class Docente extends Pessoa
{
	ArrayList <String> disciplinas;
	
	public Docente(String nome, String rg, String cpf, String nomePai, String nomeMae)
	{
		super(nome, rg, cpf, nomePai, nomeMae);
		disciplinas = new ArrayList<String>();
	}
	
	public double tempAposentadoria(double tempoMinimo, double tempoTrabalhado)
	{
		return tempoMinimo - tempoTrabalhado;
	}
	
	public void atribuirDisciplinas(String disciplina)
	{
		disciplinas.add(disciplina);
	}
	
	public void imprimeDisciplinas()
	{
		for(int i = 0; i < disciplinas.size(); i++)
		{
			System.out.println(disciplinas.get(i));
		}
	}
}
