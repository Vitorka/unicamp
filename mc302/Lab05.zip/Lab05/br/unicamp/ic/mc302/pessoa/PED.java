package br.unicamp.ic.mc302.pessoa;

public class PED extends PosGraduando
{
	private Docente ped;
	
	public PED(String nome, String rg, String cpf, 
		       String nomePai, String nomeMae, String ra, String curso, int cc)
	{
		super(nome, rg, cpf, nomePai, nomeMae, ra, curso, cc);
		ped = new Docente(nome, rg, cpf, nomePai, nomeMae);
	}
	
	//Atribui as disciplinas que o PED, sendo também um docente, pode pegar para lecionar
	public void atribuiDisciplinas(String disciplina)
	{
		ped.atribuirDisciplinas(disciplina);
	}
	
	//Calcula o tempo de aposentadoria do PED, sendo ele, também, um docente
	public double tempoAposentadoria(double tempoMin, double tempoTrabalhado)
	{
		return ped.tempAposentadoria(tempoMin, tempoTrabalhado);
	}
	
	public void imprimeDiscip()
	{
		ped.imprimeDisciplinas();
	}
}
