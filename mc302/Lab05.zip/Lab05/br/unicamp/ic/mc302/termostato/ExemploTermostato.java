package br.unicamp.ic.mc302.termostato;

public class ExemploTermostato 
{

	public static void main(String[] args) 
	{
		
		Termometro aux;
		aux = new Termometro();
		
		aux.setTempRequerida((float)Math.random() * 5);;
		aux.fazerMonitoramento();
		aux.chaveLigada();

	}

}
