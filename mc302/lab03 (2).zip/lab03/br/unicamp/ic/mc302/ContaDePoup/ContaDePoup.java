package br.unicamp.ic.mc302.ContaDePoup;

import br.unicamp.ic.mc302.conta.Conta;

public class ContaDePoup extends Conta {
    private double indice; // indice de rendimento
    
    public ContaDePoup(double sal, double indice) { 
    	super(sal);
    	this.indice = indice;
    }
    
    public double calcula( ){  // calcula e deposita o rendimento
        double i = indice*getSaldo(); 
        credita(i);
        return i;
    }
    public void retira(double v) { 
    	credita(-v);
    }
    
    public double getIndice()
    {
    	return indice;
    }
    
} // fim da classe ContaDePoup

