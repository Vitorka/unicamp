package br.unicamp.ic.mc302.documento2;

public class Encomenda extends CartaRegistrada {
	
	private String conteudo;
	
	public Encomenda(String nome, String num, String conteudo)
	{
		super(nome, num);
		this.conteudo = conteudo;
	}
	
	public void imprimir()
	{
		System.out.println(conteudo);
	}
}
