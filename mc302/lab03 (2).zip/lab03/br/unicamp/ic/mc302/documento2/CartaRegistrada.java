package br.unicamp.ic.mc302.documento2;

public class CartaRegistrada extends Carta2 {	
	
	private String data;
	private String local;
	
	public CartaRegistrada(String data, String local)
	{
		this.data = data;
		this.local = local;
	}
	
	public void imprimir()
	{
		System.out.println(data);
		System.out.println(local);
	}
	

}
