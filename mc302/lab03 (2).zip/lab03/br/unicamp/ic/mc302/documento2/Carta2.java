package br.unicamp.ic.mc302.documento2;

public class Carta2 extends Documento2 {

    private String transporte;
    
    public void anexar() {
        System.out.println( "Anexa � Carta.");
    }
}