package br.unicamp.ic.mc302.conta;

public class Conta {
    private double saldo; 
    public Conta (double sal) {saldo = sal;}
    public void credita(double valor) {saldo+= valor;}
    protected double getSaldo ( ) {return saldo;}
    protected double setSaldo(double saldo)
    {
    	return this.saldo = saldo;
    }
}
