package br.unicamp.ic.mc302.conta;

import br.unicamp.ic.mc302.ContaDePoup.ContaDePoup;

public class ExemploConta {

    public static void main(String args[]) {

        Conta c1 = new Conta(100);
        double a=c1.getSaldo();
        
        ContaDePoup c2 = new ContaDePoup(100, Math.random());
        double b = c1.getSaldo();
        double i = c2.getIndice();
        c2.calcula( );
        c2.credita(10);
    }
}


