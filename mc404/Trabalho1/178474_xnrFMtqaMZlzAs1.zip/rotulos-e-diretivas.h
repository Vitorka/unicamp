#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#ifndef ROTULOS_E_DIRETIVAS_H_INCLUDED_
#define ROTULOS_E_DIRETIVAS_H_INCLUDED_

typedef struct rot {
    char nome_rotulo[65];
    char endereco[4];
    int rotulo_existente;
    int dir_esq;
    long int pos_mont;
    struct rot *prox;
}rotulos;

typedef struct direct {
    char argumento1[65];
    char argumento2[11];
    int set_existente;
    struct direct *prox;
}sets;

typedef struct map {
    char palavra[11];
    char rotulo_dir[65];
    char rotulo_esq[65];
    char set[65];
    int num_linha;
} mapa;

rotulos *insere_rotulos(char *rotulo, rotulos *raiz, long int pos_mont, int dir_esq, int rotulo_existente);
sets *insere_sets(char *argumento1, char *argumento2, sets *inicio, int set_existente);
void adiciona_palavras(char *palavra, mapa *mapa_memoria, long int linha);
void imprime_lista_rotulos(rotulos *rot);
int adiciona_instrucao(char *opcode, char *endereco, mapa *mapa_memoria, long int linha, int dir_esq);
void imprime_lista_sets(sets *set);
void completa_mapa(rotulos *inicio_rotulos, sets *inicio_sets, mapa *mapa_memoria, int argc, FILE *arqs);

#endif
