#include <stdio.h>
#include "rotulos-e-diretivas.h"
#include "conversoes.h"
#ifndef EEROS_E_IMPRESSOES_H_INCLUDED_
#define ERROS_E_IMPRESSOES_H_INCLUDED_

void imprime_mapa(mapa *mapa_memoria, int argc, FILE *arqs);
void imprime_erros(int num_linha, char *mensagem_erro, int argc, FILE *arqs);

#endif
