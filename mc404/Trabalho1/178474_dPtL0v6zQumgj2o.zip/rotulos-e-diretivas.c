#include "rotulos-e-diretivas.h"
#include "conversoes.h"
#include "erros-e-impressoes.h"

//Insere um novo rotulo a lista de rotulos
rotulos *insere_rotulos(char *nome_rotulo, rotulos *inicio, long int pos_mont, int dir_esq, int rotulo_existente) {
    
    rotulos *new_rotulo;
    
    new_rotulo = (rotulos *)malloc(sizeof(rotulos));
    strcpy(new_rotulo->nome_rotulo, nome_rotulo);
    strcpy(new_rotulo->endereco, dec_para_hexa(pos_mont));
    new_rotulo->pos_mont = pos_mont;
    new_rotulo->rotulo_existente = rotulo_existente;
    new_rotulo->dir_esq = dir_esq;
    
    if(inicio == NULL) {
        new_rotulo->prox = NULL;
    } else {
        new_rotulo->prox = inicio;
    }
    
    return new_rotulo;
}

//Insere um novo set, na lista de sets
sets *insere_sets(char *argumento1, char *argumento2, sets *inicio, int set_existente) {
    
    sets *new_set;
    int i;
    
    for(i = 0; (i < strlen(argumento2)) && (set_existente); i++) {
        argumento2[i] = toupper(argumento2[i]);
    }
    
    new_set = (sets *)malloc(sizeof(sets));
    strcpy(new_set->argumento1, argumento1);
    new_set->set_existente = set_existente;
    
    if(strlen(argumento2) == 3) {
        strcpy(new_set->argumento2, argumento2);
    } else {
        strcpy(new_set->argumento2, &argumento2[7]);
    }
    
    if(inicio == NULL) {
        new_set->prox = NULL;
    } else {
        new_set->prox = inicio;
    }
    
    return new_set;
}

/*Verifica se a diretiva eh um .set, armazenando-o em uma lista, ou um .word, 
 *adicionando-o ao mapa de memoria*/
void adiciona_palavras(char *palavra, mapa *mapa_memoria, long int linha) {
    int i, j;
    
    for(i = strlen(palavra) - 1, j = strlen(mapa_memoria[linha].palavra) - 1; i >= 0; i--, j--) {
        mapa_memoria[linha].palavra[j] = palavra[i];
    }
}

//Adiciona uma instrucao em sua respectiva posicao
int adiciona_instrucao(char *opcode, char *endereco, mapa *mapa_memoria, long int linha, int dir_esq) {
    
    int i, j;
    
    //Veririca se adicionara a instrucao a esquerda
    if(dir_esq == 1) {
        for(i = 0; i < 2; i++) {
            mapa_memoria[linha].palavra[i] = opcode[i];
        }
        
        for(i = 2, j = 0; i < 5; i++, j++) {
            mapa_memoria[linha].palavra[i] = endereco[j];
        }
        return 1;
    }
    //Verifica se adicionara a instrucao a direita
    else if((dir_esq == 2) && (mapa_memoria[linha].palavra[0] != '*')) {
        
        for(i = 5, j = 0; i < 7; i++, j++) {
            mapa_memoria[linha].palavra[i] = opcode[j];
        }
        
        for(i = 7, j = 0; i < 10; i++, j++) {
            mapa_memoria[linha].palavra[i] = endereco[j];
        }
        return 1;
    } else {
        return 0;
    }
}

//Adiciona os enderecos correspondentes aos rotulos
void completa_mapa(rotulos *inicio_rotulos, sets *inicio_sets, mapa *mapa_memoria, int argc, FILE *arqs) {
    
    rotulos *rot;
    sets *set;
    int i, j;
    
    for(i = 0; i < 1024; i++) {
        for(j = 0; j < 11; j++) {
            
            //Completa os enderecos de instrucoes
            if(mapa_memoria[i].palavra[j] == '-') {
                for(rot = inicio_rotulos; rot != NULL; rot = rot->prox) {
                    
                    //Caso o endereco a ser completado esteja do lado esquerdo
                    if(j <= 4) {
                        if((!strcmp(rot->nome_rotulo, mapa_memoria[i].rotulo_esq)) && (rot->rotulo_existente)) {
                            strcpy(&mapa_memoria[i].palavra[2], rot->endereco);
                            break;
                        }
                    }
                    //Caso o endereco a ser completado esteja do lado direito
                    else {
                        if((!strcmp(rot->nome_rotulo, mapa_memoria[i].rotulo_dir)) && (rot->rotulo_existente)) {
                            strcpy(&mapa_memoria[i].palavra[2], rot->endereco);
                            break;
                        }
                    }
                }
                
                if(!rot) {
                    imprime_erros(mapa_memoria[i].num_linha, "Erro de sintaxe na linha", argc, arqs);
                }
            }
            //Completa os enderecos de .word e .wfill
            else if(mapa_memoria[i].palavra[j] == '+') {
                for(rot = inicio_rotulos; rot != NULL; rot = rot->prox) {
                    
                    if((!strcmp(rot->nome_rotulo, mapa_memoria[i].rotulo_esq)) && (rot->rotulo_existente)) {
                        memset(mapa_memoria[i].palavra, '0', 10);
                        mapa_memoria[i].palavra[10] = '\0';
                        strcpy(&mapa_memoria[i].palavra[7], rot->endereco);
                        break;
                    }
                }
                
                for(set = inicio_sets; (set != NULL) && (rot == NULL); set = set->prox) {
                    
                    if((!strcmp(set->argumento1, mapa_memoria[i].set)) && (set->set_existente)) {
                        memset(mapa_memoria[i].palavra, '0', 10);
                        mapa_memoria[i].palavra[10] = '\0';
                        strcpy(&mapa_memoria[i].palavra[7], set->argumento2);
                        break;
                    }
                }
                
                if((rot == NULL) && (set == NULL)) {
                    imprime_erros(mapa_memoria[i].num_linha, "Erro de sintaxe na linha", argc, arqs);
                }
            }
        }
    }
}


void imprime_lista_rotulos(rotulos *rot) {
    if(rot != NULL){
        printf("%s ", rot->nome_rotulo);
        printf("%s ", rot->endereco);
        printf("%d ", rot->rotulo_existente);
        printf("%d\n", rot->dir_esq);
        imprime_lista_rotulos(rot->prox);
    }    
}

void imprime_lista_sets(sets *set) {
    if(set != NULL){
        printf("%s ", set->argumento1);
        printf("%s\n", set->argumento2);
        imprime_lista_sets(set->prox);
    }   
}



