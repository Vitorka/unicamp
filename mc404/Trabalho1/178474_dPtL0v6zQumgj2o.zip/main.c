#include "verifica.h"
#include "erros-e-impressoes.h"
#include "conversoes.h"
#include "rotulos-e-diretivas.h"

int main(int argc, char**argv)
{
    FILE *arqe, *arqs;
    char linha[4096], linha_de_verificacao[4096];
    mapa *mapa_memoria;
    char *palavra;
    long int i, j;
    int dir_esq = 1; /*Variavel que define se a montagem devera ser a esquerda ou a direita, sendo:
    1 = esquerda e 2 = direita*/
    int num_linha = 1; //Armazena o numero da linha do arquivo de entrada
    long int pos_mont = 0; //Armazena a posicao da matriz de comandos 
    rotulos *inicio_rotulos = NULL;
    sets *inicio_sets = NULL;
    
    mapa_memoria = malloc(1024 * sizeof(mapa));
    
    for(i = 0; i < 1024; i++){
        memset(mapa_memoria[i].palavra, '*', 10);
        memset(mapa_memoria[i].rotulo_esq, '0', 64);
        memset(mapa_memoria[i].rotulo_dir, '0', 64);
        memset(mapa_memoria[i].set, '0', 64);
        mapa_memoria[i].palavra[10] = '\0';
        mapa_memoria[i].rotulo_esq[64] = '\0';
        mapa_memoria[i].rotulo_dir[64] = '\0';
        mapa_memoria[i].set[64] = '\0';
    }
    
    /*Abre os arquivos de entrada e verifica se foram abertos corretamente*/
    arqe = fopen(argv[1], "r");
    if(argc == 3) {
        arqs = fopen(argv[2], "w");
    }
    if((arqe == NULL) && (arqs == NULL)) {
        //printf("Não foi possivel abrir o arquivo\n");
    }
    else {
        //printf("Arquivo aberto com sucesso\n");
    }
    
    
    //Realiza a leitura do arquivo
    while(fgets(linha, 4096, arqe)) {    
        
        //Verifica se nao ha erro de sintaxe na linha 
        strcpy(linha_de_verificacao, linha);
        palavra = strtok(linha_de_verificacao, " \n\t");
        
        int verifica_linha = 1;
        
        if(strcmp(linha, "\n")) {
            verifica_linha = verifica_sintaxe_linha(palavra, 0);
        }
        
        palavra = strtok(linha, " \n\t");
        
        if(verifica_linha) {
            while(palavra != NULL) {
                
                //Verifica se eh um rotulo
                if(verifica_rotulo(palavra)) {
                    
                    rotulos *rot = verifica_rotulo_existente(inicio_rotulos, palavra);
                    
                    if(!rot) {
                        inicio_rotulos = insere_rotulos(palavra, inicio_rotulos, pos_mont, dir_esq, 1);
                    } else {
                        rot->rotulo_existente = 1;
                        strcpy(rot->endereco, dec_para_hexa(pos_mont));
                        rot->pos_mont = pos_mont;
                    }
                    
                }
                //Verifica se eh uma diretiva
                else if(verifica_diretiva(palavra)) {
                    
                    int tipo_diretiva = verifica_diretiva(palavra);
                    
                    //Caso a diretiva seja um .set, armazena-a em uma lista
                    if(tipo_diretiva == 1) {
                        
                        char *simbolo = strtok(NULL, " \n\t");
                        char *valor_set = strtok(NULL, " \n\t");
                        
                        //Verifica se os argumento subsequentes, sao um simbolo e um numero
                        if((simbolo != NULL) && (valor_set != NULL)) {
                            
                            //Verifica se o simbolo eh uma palavra valida
                            if((simbolo != NULL) && (palavra_valida(simbolo))) {
                                
                                sets *set = verifica_set_existente(inicio_sets, simbolo);
                                
                                if(!set) {
                                    
                                    if(dec_valido(valor_set)) {
                                        inicio_sets =  insere_sets(simbolo, dec_para_hexa(dec_para_dec(valor_set)), 
                                                                   inicio_sets, 1);
                                    }
                                    else if(hexa_valido(valor_set)) {
                                        inicio_sets =  insere_sets(simbolo, &valor_set[2], inicio_sets, 1);
                                    } else {
                                        imprime_erros(num_linha, "Argumento Invalido", argc, arqs);
                                    }
                                } else {
                                    set->set_existente = 1;
                                }
                            } else {
                                imprime_erros(num_linha, "Argumento Invalido", argc, arqs);
                            }
                        } else {
                            imprime_erros(num_linha, "Falta Argumentos", argc, arqs);
                        }
                    }
                    //Caso seja um .org
                    else if(tipo_diretiva == 2) {
                        
                        palavra = strtok(NULL, " \n\t");
                        if(palavra != NULL) {
                            if(hexa_valido(palavra)) {
                                pos_mont = hexa_para_decimal(palavra);
                                if(pos_mont > 1023) {
                                    imprime_erros(num_linha, "Acesso invalido de memoria", argc, arqs);
                                }
                            }
                            else if(dec_valido(palavra)) {
                                pos_mont = dec_para_dec(palavra);
                                
                                if(pos_mont > 1023) {
                                    imprime_erros(num_linha, "Acesso invalido de memoria", argc, arqs);
                                }
                            }
                            else {
                                imprime_erros(num_linha, "Argumento invalido", argc, arqs);
                            }
                        } else {
                            imprime_erros(num_linha, "Falta argumento", argc, arqs);
                        }
                        if(dir_esq == 2) {
                            dir_esq = 1;
                        }
                    }
                    //Caso seja um .align
                    else if(tipo_diretiva == 3) {
                        
                        palavra = strtok(NULL, " \n\t");
                        
                        int align;
                        
                        //Veririfica se o argumento1 existe
                        if(palavra != NULL) {
                            if(dec_valido(palavra)) {
                                
                                align = dec_para_dec(palavra);
                                
                                //Verifica se a montagem se encontra a direita
                                if(dir_esq == 2) {
                                    dir_esq = 1;
                                    if(pos_mont < 1023) {
                                        pos_mont++;
                                    }
                                }
                                
                                //Realiza o align se nao ultrapassar o maximo de linhas
                                if(pos_mont <= 1023) {
                                    
                                    while((pos_mont % align) && (pos_mont < 1023)) {
                                        pos_mont++;
                                    }
                                } else {
                                    imprime_erros(num_linha, "Acesso a posicao invalida", argc, arqs);
                                }
                            } else {
                                imprime_erros(num_linha, "Valor Invalido", argc, arqs);
                            }
                        } else {
                            imprime_erros(num_linha, "Falta argumento", argc, arqs);
                        }
                    }
                    //Caso a diretiva seja um .wfill
                    else if(tipo_diretiva == 4) {
                        
                        palavra = strtok(NULL, " \n\t");
                        //Verifica se o argumento1 existe e se eh um decimal valido
                        if((palavra != NULL) && (dec_valido(palavra))) {
                            
                            int nwfill = dec_para_dec(palavra);
                            int id_encontrado = 0;
                            palavra = strtok(NULL, " \n\t");
                            
                            if(dir_esq == 2) {
                                dir_esq = 1;
                                
                                if(pos_mont < 1023) {
                                    pos_mont++;
                                } else {
                                    imprime_erros(num_linha, "Acesso a posicao invalida", argc, arqs);
                                }
                            }
                            
                            //Verifica se o valor a ser adicionado eh um hexadecimal
                            if(hexa_valido(palavra)) {
                                strcpy(palavra, &palavra[9]);
                                id_encontrado = 1;
                            }
                            //Verifica se o valor a ser adicionado eh um decimal
                            else if(dec_valido(palavra)) {
                                palavra = dec_para_hexa(dec_para_dec(palavra));
                                id_encontrado = 1;
                            } 
                            //Verifica se o valor a ser adicionado eh uma palavra
                            else if(palavra_valida(palavra)) {
                                
                                rotulos *rot;
                                sets *set;
                                
                                for(rot = inicio_rotulos; (rot != NULL) && (!id_encontrado); rot = rot->prox) {
                                    if(!strcmp(rot->nome_rotulo, palavra)) {
                                        strcpy(palavra, rot->endereco);
                                        id_encontrado = 1;
                                    }
                                }
                                
                                for(set = inicio_sets; (set != NULL) && (!id_encontrado); set = set->prox) {
                                    if(!strcmp(set->argumento1, palavra)) {
                                        strcpy(palavra, set->argumento2);
                                        id_encontrado = 1;
                                    }
                                }
                            }
                            //Adiciona os valores correspondentes
                            if((pos_mont + nwfill) <= 1023) {
                                
                                if((id_encontrado)) {
                                    for(i = pos_mont, j = 0; j < nwfill; i++, j++) {
                                        memset(mapa_memoria[i].palavra, '0', 10);
                                        adiciona_palavras(palavra, mapa_memoria, i);
                                    }
                                }
                                //Caso o simbolo nao tenha sido achado, armazena a palavra para posterior verificacao
                                else { 
                                    inicio_sets =  insere_sets(palavra, "000\0", inicio_sets, 0);
                                    inicio_rotulos = insere_rotulos(palavra, inicio_rotulos, pos_mont, dir_esq, 0);
                                    
                                    for(i = pos_mont, j = 0; j < nwfill; i++, j++) {
                                        memset(mapa_memoria[i].palavra, '+', 10);
                                        strcpy(mapa_memoria[i].rotulo_esq, palavra);
                                        strcpy(mapa_memoria[i].rotulo_dir, palavra);
                                        strcpy(mapa_memoria[i].set, palavra);
                                    }
                                }
                                pos_mont += nwfill;
                            } else {
                                imprime_erros(num_linha, "Acesso a posicao invalida", argc, arqs);
                            }
                        } else {
                            imprime_erros(num_linha, "Argumento invalido", argc, arqs);
                        }
                    }
                    //Caso a diretiva seja um .word
                    else if(tipo_diretiva == 5) {
                        
                        palavra = strtok(NULL, " \n\t");
                        
                        //Verifica se o identificador de escrita esta a esquerda. Caso contrario, emite um erro
                        if(dir_esq == 1) {
                            
                            //Verifica se a palavra seguinte eh um hexadecimal valido
                            if(hexa_valido(palavra)) {
                                memset(mapa_memoria[pos_mont].palavra, '0', 10);
                                adiciona_palavras(&palavra[9], mapa_memoria, pos_mont);
                            }
                            //Verifica se a palavra seguinte eh um decimal valido
                            else if(dec_valido(palavra)) {
                                memset(mapa_memoria[pos_mont].palavra, '0', 10);
                                adiciona_palavras(dec_para_hexa(dec_para_dec(palavra)), mapa_memoria, pos_mont);
                            }
                            //Verifica se a palavra seguinte eh um rotulo ou simbolo
                            else if(palavra_valida(palavra)) {
                                
                                rotulos *rot;
                                sets *set;
                                int id_encontrado = 0;
                                
                                memset(mapa_memoria[pos_mont].palavra, '0', 10);
                                
                                for(rot = inicio_rotulos; (rot != NULL) && (!id_encontrado); rot = rot->prox) {
                                    if(!strcmp(rot->nome_rotulo, palavra)) {
                                        adiciona_palavras(rot->endereco, mapa_memoria, pos_mont);
                                        id_encontrado = 1;
                                    }
                                }
                                
                                for(set = inicio_sets; (set != NULL) && (!id_encontrado); set = set->prox) {
                                    if(!strcmp(set->argumento1, palavra)) {
                                        adiciona_palavras(set->argumento2, mapa_memoria, pos_mont);
                                        id_encontrado = 1;
                                    }
                                }
                                
                                //Caso o simbolo ou rotulo nao tenha sido encontrado nas listas de rotulos e sets
                                if(!id_encontrado) {
                                    memset(mapa_memoria[pos_mont].palavra, '+', 10);
                                    strcpy(mapa_memoria[pos_mont].rotulo_esq, palavra);
                                    strcpy(mapa_memoria[pos_mont].rotulo_dir, palavra);
                                    strcpy(mapa_memoria[pos_mont].set, palavra);
                                    mapa_memoria[pos_mont].num_linha = num_linha;
                                }
                            }
                            //printf("word = %ld\n", pos_mont);
                            if(pos_mont < 1023) {
                                pos_mont++;
                            }
                        } else {
                            imprime_erros(num_linha, "Acesso invalido de memoria", argc, arqs);
                        }
                    }
                }
                //Veririfica se eh um comentario
                else if(verifica_comentario(palavra)) {
                    while(palavra != NULL) {
                        palavra = strtok(NULL, " \n\t");
                    }
                }
                //Verifica se eh uma instrucao
                else if(strcmp(retorna_instrucao(palavra), "00")) {
                    
                    char *opcode = retorna_instrucao(palavra);
                    
                    //Caso nao precise de um endereco, apenas armazena o opcode da instrucao
                    if(!(strcmp(opcode, "0A")) || !(strcmp(opcode, "14")) || !(strcmp(opcode, "15"))) {
                        adiciona_instrucao(opcode, "000", mapa_memoria, pos_mont, dir_esq);
                    }
                    
                    palavra = strtok(NULL, " \n");
                    
                    //Verifica se ela esta entre aspas como especificado
                    if((palavra != NULL) && (palavra[0] == '\"') && (palavra[strlen(palavra) - 1]) == '\"') {
                        
                        for(i = 0; i < strlen(palavra); i++) {
                            palavra[i] = palavra[i + 1];
                        }
                        palavra[strlen(palavra) - 1] = '\0';
                        
                        //Verifica se o endereco eh um hexadecimal valido
                        if(hexa_valido(palavra)) {
                            
                            for(i = 0; i < strlen(palavra); i++) {
                                palavra[i] = toupper(palavra[i]);
                            }
                            adiciona_instrucao(opcode, &palavra[9], mapa_memoria, pos_mont, dir_esq);
                        }
                        //Verifica se o endereco eh um decimal valido
                        else if(dec_valido(palavra)) {
                            adiciona_instrucao(opcode, dec_para_hexa(dec_para_dec(palavra)), mapa_memoria, 
                                               pos_mont, dir_esq);
                        }
                        //Verifica se eh uma palavra palavra valida
                        else if(palavra_valida(palavra)) {
                            
                            rotulos *rot = verifica_rotulo_existente(inicio_rotulos, palavra);
                            
                            //Verifica se eh um rotulo existente
                            if(rot) {
                                
                                /*Verifica se a instrucao eh um salto ou armazenamento que possui opcode diferente para 
                                direita e esquerda*/
                                if((!strcmp(opcode, "0D0E")) || (!strcmp(opcode, "0F10")) || (!strcmp(opcode,"1213"))){
                                    
                                    //Caso seja uma instruca a esquerda
                                    if(rot->dir_esq == 1) {
                                        if(!adiciona_instrucao(opcode, rot->endereco, mapa_memoria, pos_mont,dir_esq)){
                                            imprime_erros(num_linha, "Lado esquerdo da palavra de memoria, vazio", 
                                                          argc, arqs);
                                        }
                                    }
                                    //Caso seja uma instrucao a direita
                                    else if(rot->dir_esq == 2) {
                                        
                                        if(!adiciona_instrucao(&opcode[2], rot->endereco,mapa_memoria, 
                                                               pos_mont,dir_esq)){
                                            imprime_erros(num_linha, "Lado esquerdo da palavra de memoria, vazio", argc, 
                                                          arqs);
                                        }
                                    }   
                                } else {
                                    if(!adiciona_instrucao(opcode, rot->endereco, mapa_memoria, pos_mont, dir_esq)) {
                                        imprime_erros(num_linha, "Lado esquerdo da palavra de memoria, vazio", argc, 
                                                      arqs);
                                    }    
                                }
                            } else {
                                if(!adiciona_instrucao(opcode, "---", mapa_memoria, pos_mont, dir_esq)) {
                                    imprime_erros(num_linha, "Lado esquerdo da palavra de memoria, vazio", argc, 
                                                  arqs);   
                                }
                                
                                if(dir_esq == 1) {
                                    strcpy(mapa_memoria[pos_mont].rotulo_esq, palavra);
                                } else {
                                    strcpy(mapa_memoria[pos_mont].rotulo_dir, palavra);
                                }
                                mapa_memoria[pos_mont].num_linha = num_linha;
                                inicio_rotulos = insere_rotulos(palavra, inicio_rotulos, pos_mont, dir_esq, 0);
                            }  
                        }
                    }
                    //Modifica o identificador para direita ou esquerda, de acordo com a posicao atual
                    if(dir_esq == 1) {
                        dir_esq = 2;
                    } else {
                        dir_esq = 1;
                        if(pos_mont < 1023) {
                            pos_mont++;
                        }
                    }
                }
                
                palavra = strtok(NULL, " \n\t");
            }
        } else {
            imprime_erros(num_linha, "Erro de sintaxe na linha", argc, arqs);
        }
        num_linha++;
    }
    
    //Completa com o endereco, 
    completa_mapa(inicio_rotulos, inicio_sets, mapa_memoria, argc, arqs);
    
    //Completa com zeros, as posicoes de memoria que nao foram preenchidas
    for(i = 0; i < 1024; i++, j = 0) {
        if(mapa_memoria[i].palavra[0] != '*') {
            for(j = 0; j < 10; j++) {
                if(mapa_memoria[i].palavra[j] == '*') {
                    mapa_memoria[i].palavra[j] = '0';
                }
            }
        }
    }

    imprime_mapa(mapa_memoria, argc, arqs);
    
    free(mapa_memoria);
    
    fclose(arqe);
    if(argc == 3){
        fclose(arqs);
    }
    
    return 0;
}

