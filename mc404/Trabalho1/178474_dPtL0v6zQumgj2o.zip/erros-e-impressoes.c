#include <stdio.h>
#include "rotulos-e-diretivas.h"
#include "conversoes.h"

void imprime_mapa(mapa *mapa_memoria, int argc, FILE *arqs) {
    int i, j;
    
    if(argc == 2) {
        for(i = 0; i < 1024; i++, j = 0) {
            if(mapa_memoria[i].palavra[0] != '*') {
                printf("%s ", dec_para_hexa(i));
                for(j = 0; j < 10; j++){
                    printf("%c", mapa_memoria[i].palavra[j]);
                    if((j == 1) || (j == 4) || (j == 6)){
                        printf(" ");
                    }
                }
                printf("\n");
            }
        }
    } else {
        
        for(i = 0; i < 1024; i++, j = 0) {
            if(mapa_memoria[i].palavra[0] != '*') {
                
                fprintf(arqs, "%s ", dec_para_hexa(i));
                
                for(j = 0; j < 10; j++){
                    
                    fprintf(arqs, "%c", mapa_memoria[i].palavra[j]);
                    
                    if((j == 1) || (j == 4) || (j == 6)){
                        fprintf(arqs, "%s", " ");
                    }
                }        
                fprintf(arqs, "%s", "\n");
            }
        }
        
    }
}

int imprime_erros(int num_linha, char *mensagem_erro, int argc, FILE *arqs) {
    
    if(argc == 2) {
        printf("ERROR on line %d\n%s!\n", num_linha, mensagem_erro);
        exit(0);
    } else {
        fprintf(arqs, "ERROR on line %d\n%s!\n", num_linha, mensagem_erro);
        exit(0);
    }
}

