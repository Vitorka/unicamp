#!/bin/bash





COMP_HEX="./comp_hex"



STR_DIV="-------------------------------------------"



TEST[0]="corretos/t1.txt"
TEST[1]="corretos/t2.txt"
TEST[2]="corretos/t3.txt"
TEST[3]="corretos/t4.txt"
TEST[4]="corretos/t5.txt"
TEST[5]="corretos/t6.txt"
TEST[6]="corretos/t7.txt"
TEST[7]="corretos/t8.txt"
TEST[8]="corretos/t9.txt"
TEST[9]="corretos/t10.txt"
TEST[10]="corretos/t11.txt"
TEST[11]="corretos/t12.txt"
TEST[12]="corretos/t13.txt"
TEST[13]="corretos/t14.txt"
TEST[14]="corretos/t15.txt"
TEST[15]="corretos/t16.txt"
TEST[16]="corretos/t17.txt"
TEST[17]="corretos/t18.txt"
TEST[18]="corretos/t19.txt"
TEST[19]="corretos/t20.txt"
TEST[20]="corretos/t21.txt"
TEST[21]="corretos/t22.txt"
TEST[22]="corretos/t23.txt"


HEX[0]="corretos/t1.txt.hex"
HEX[1]="corretos/t2.txt.hex"
HEX[2]="corretos/t3.txt.hex"
HEX[3]="corretos/t4.txt.hex"
HEX[4]="corretos/t5.txt.hex"
HEX[5]="corretos/t6.txt.hex"
HEX[6]="corretos/t7.txt.hex"
HEX[7]="corretos/t8.txt.hex"
HEX[8]="corretos/t9.txt.hex"
HEX[9]="corretos/t10.txt.hex"
HEX[10]="corretos/t11.txt.hex"
HEX[11]="corretos/t12.txt.hex"
HEX[12]="corretos/t13.txt.hex"
HEX[13]="corretos/t14.txt.hex"
HEX[14]="corretos/t15.txt.hex"
HEX[15]="corretos/t16.txt.hex"
HEX[16]="corretos/t17.txt.hex"
HEX[17]="corretos/t18.txt.hex"
HEX[18]="corretos/t19.txt.hex"
HEX[19]="corretos/t20.txt.hex"
HEX[20]="corretos/t21.txt.hex"
HEX[21]="corretos/t22.txt.hex"
HEX[22]="corretos/t23.txt.hex"












OUT[0]="saidas/t1.txt.hex"
OUT[1]="saidas/t2.txt.hex"
OUT[2]="saidas/t3.txt.hex"
OUT[3]="saidas/t4.txt.hex"
OUT[4]="saidas/t5.txt.hex"
OUT[5]="saidas/t6.txt.hex"
OUT[6]="saidas/t7.txt.hex"
OUT[7]="saidas/t8.txt.hex"
OUT[8]="saidas/t9.txt.hex"
OUT[9]="saidas/t10.txt.hex"
OUT[10]="saidas/t11.txt.hex"
OUT[11]="saidas/t12.txt.hex"
OUT[12]="saidas/t13.txt.hex"
OUT[13]="saidas/t14.txt.hex"
OUT[14]="saidas/t15.txt.hex"
OUT[15]="saidas/t16.txt.hex"
OUT[16]="saidas/t17.txt.hex"
OUT[17]="saidas/t18.txt.hex"
OUT[18]="saidas/t19.txt.hex"
OUT[19]="saidas/t20.txt.hex"
OUT[20]="saidas/t21.txt.hex"
OUT[21]="saidas/t22.txt.hex"
OUT[22]="saidas/t23.txt.hex"











rm -rf saidas

mkdir saidas

for((I = 0; I < "${#TEST[@]}"; I++))
do
    echo $STR_DIV
    echo "${TEST[$I]}"

    EX="./$1"   



    $EX ${TEST[$I]} ${OUT[$I]}

    $COMP_HEX ${OUT[$I]} ${HEX[$I]}


    
done

